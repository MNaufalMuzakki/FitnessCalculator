﻿namespace FitnessCalculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lblBMI = new Label();
            lblBMR = new Label();
            lblHRZoneBB = new Label();
            lblBFP = new Label();
            txtWeight = new TextBox();
            txtHeight = new TextBox();
            txtAge = new TextBox();
            txtNeck = new TextBox();
            txtWaist = new TextBox();
            btnCalculate = new Button();
            rbtnMale = new RadioButton();
            rbtnFemale = new RadioButton();
            txtHip = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            lblHRZoneB = new Label();
            lblHRZoneT = new Label();
            lblBFPCat = new Label();
            label6 = new Label();
            groupBox1 = new GroupBox();
            lblBFPW6 = new Label();
            lblBFPW1 = new Label();
            lblBFPW2 = new Label();
            lblBFPW3 = new Label();
            lblBFPW5 = new Label();
            lblBFPW4 = new Label();
            groupBox2 = new GroupBox();
            lblBFPP6 = new Label();
            lblBFPP1 = new Label();
            lblBFPP2 = new Label();
            lblBFPP3 = new Label();
            lblBFPP5 = new Label();
            lblBFPP4 = new Label();
            groupBox3 = new GroupBox();
            lblBMICat1 = new Label();
            lblBMICat2 = new Label();
            lblBMICat4 = new Label();
            lblBMICat3 = new Label();
            groupBox4 = new GroupBox();
            lblBMRCalHr = new Label();
            lblBMRCalHs = new Label();
            label45 = new Label();
            label46 = new Label();
            lblBMRCalMid = new Label();
            label48 = new Label();
            lblBMRCalLr = new Label();
            label50 = new Label();
            lblBMRCalLs = new Label();
            label52 = new Label();
            lblBMICat = new Label();
            lblHRZoneA = new Label();
            lblHRZoneAB = new Label();
            groupBox5 = new GroupBox();
            label38 = new Label();
            label41 = new Label();
            label47 = new Label();
            label49 = new Label();
            label51 = new Label();
            groupBox6 = new GroupBox();
            label53 = new Label();
            btnClear = new Button();
            btnClearH = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            label54 = new Label();
            label55 = new Label();
            label56 = new Label();
            label57 = new Label();
            txtBoxBFP = new TextBox();
            txtBoxBMI = new TextBox();
            groupBox7 = new GroupBox();
            pictureBox1 = new PictureBox();
            label59 = new Label();
            groupBox8 = new GroupBox();
            label58 = new Label();
            label65 = new Label();
            label60 = new Label();
            groupBox10 = new GroupBox();
            label66 = new Label();
            label67 = new Label();
            label64 = new Label();
            label63 = new Label();
            label62 = new Label();
            label61 = new Label();
            lblHRMax = new Label();
            groupBox11 = new GroupBox();
            label68 = new Label();
            label69 = new Label();
            label70 = new Label();
            label71 = new Label();
            groupBox12 = new GroupBox();
            groupBox9 = new GroupBox();
            groupBox13 = new GroupBox();
            groupBox14 = new GroupBox();
            groupBox15 = new GroupBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox6.SuspendLayout();
            groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox8.SuspendLayout();
            groupBox10.SuspendLayout();
            groupBox11.SuspendLayout();
            groupBox12.SuspendLayout();
            groupBox9.SuspendLayout();
            groupBox13.SuspendLayout();
            groupBox14.SuspendLayout();
            groupBox15.SuspendLayout();
            SuspendLayout();
            // 
            // lblBMI
            // 
            lblBMI.AutoSize = true;
            lblBMI.BackColor = Color.Transparent;
            lblBMI.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblBMI.Location = new Point(6, 41);
            lblBMI.Name = "lblBMI";
            lblBMI.Size = new Size(247, 38);
            lblBMI.TabIndex = 0;
            lblBMI.Text = "Body Mass Index:";
            // 
            // lblBMR
            // 
            lblBMR.AutoSize = true;
            lblBMR.BackColor = Color.Transparent;
            lblBMR.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblBMR.Location = new Point(6, 147);
            lblBMR.Name = "lblBMR";
            lblBMR.Size = new Size(299, 38);
            lblBMR.TabIndex = 1;
            lblBMR.Text = "Basal Metabolic Rate:";
            // 
            // lblHRZoneBB
            // 
            lblHRZoneBB.AutoSize = true;
            lblHRZoneBB.BackColor = Color.Transparent;
            lblHRZoneBB.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblHRZoneBB.Location = new Point(328, 60);
            lblHRZoneBB.Name = "lblHRZoneBB";
            lblHRZoneBB.Size = new Size(86, 32);
            lblHRZoneBB.TabIndex = 3;
            lblHRZoneBB.Text = "Zona 1";
            // 
            // lblBFP
            // 
            lblBFP.AutoSize = true;
            lblBFP.BackColor = Color.Transparent;
            lblBFP.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblBFP.Location = new Point(6, 41);
            lblBFP.Name = "lblBFP";
            lblBFP.Size = new Size(293, 38);
            lblBFP.TabIndex = 4;
            lblBFP.Text = "Body Fat Percentage:";
            // 
            // txtWeight
            // 
            txtWeight.BackColor = Color.WhiteSmoke;
            txtWeight.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            txtWeight.ForeColor = SystemColors.Desktop;
            txtWeight.Location = new Point(54, 103);
            txtWeight.Name = "txtWeight";
            txtWeight.PlaceholderText = "Masukkan BB";
            txtWeight.Size = new Size(220, 39);
            txtWeight.TabIndex = 5;
            // 
            // txtHeight
            // 
            txtHeight.BackColor = Color.WhiteSmoke;
            txtHeight.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            txtHeight.ForeColor = SystemColors.Desktop;
            txtHeight.Location = new Point(54, 203);
            txtHeight.Name = "txtHeight";
            txtHeight.PlaceholderText = "Masukkan TB";
            txtHeight.Size = new Size(220, 39);
            txtHeight.TabIndex = 6;
            // 
            // txtAge
            // 
            txtAge.BackColor = Color.WhiteSmoke;
            txtAge.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            txtAge.ForeColor = SystemColors.Desktop;
            txtAge.Location = new Point(54, 303);
            txtAge.Name = "txtAge";
            txtAge.PlaceholderText = "Masukkan Usia";
            txtAge.Size = new Size(220, 39);
            txtAge.TabIndex = 7;
            // 
            // txtNeck
            // 
            txtNeck.BackColor = Color.WhiteSmoke;
            txtNeck.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            txtNeck.ForeColor = SystemColors.Desktop;
            txtNeck.Location = new Point(420, 101);
            txtNeck.Name = "txtNeck";
            txtNeck.PlaceholderText = "Masukkan LL";
            txtNeck.Size = new Size(220, 39);
            txtNeck.TabIndex = 8;
            // 
            // txtWaist
            // 
            txtWaist.BackColor = Color.WhiteSmoke;
            txtWaist.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            txtWaist.ForeColor = SystemColors.Desktop;
            txtWaist.Location = new Point(421, 194);
            txtWaist.Name = "txtWaist";
            txtWaist.PlaceholderText = "Masukkan LP";
            txtWaist.Size = new Size(220, 39);
            txtWaist.TabIndex = 9;
            // 
            // btnCalculate
            // 
            btnCalculate.BackColor = Color.Transparent;
            btnCalculate.BackgroundImageLayout = ImageLayout.None;
            btnCalculate.FlatAppearance.BorderSize = 0;
            btnCalculate.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnCalculate.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnCalculate.FlatStyle = FlatStyle.Flat;
            btnCalculate.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalculate.ForeColor = SystemColors.ActiveCaptionText;
            btnCalculate.Image = (Image)resources.GetObject("btnCalculate.Image");
            btnCalculate.Location = new Point(397, 429);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(293, 81);
            btnCalculate.TabIndex = 10;
            btnCalculate.Text = "Kalkulasi";
            btnCalculate.UseVisualStyleBackColor = false;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // rbtnMale
            // 
            rbtnMale.AutoSize = true;
            rbtnMale.BackColor = Color.Transparent;
            rbtnMale.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            rbtnMale.Location = new Point(54, 410);
            rbtnMale.Name = "rbtnMale";
            rbtnMale.Size = new Size(76, 34);
            rbtnMale.TabIndex = 11;
            rbtnMale.TabStop = true;
            rbtnMale.Text = "Pria";
            rbtnMale.UseVisualStyleBackColor = false;
            rbtnMale.CheckedChanged += rbtnMale_CheckedChanged;
            // 
            // rbtnFemale
            // 
            rbtnFemale.AutoSize = true;
            rbtnFemale.BackColor = Color.Transparent;
            rbtnFemale.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            rbtnFemale.Location = new Point(137, 410);
            rbtnFemale.Name = "rbtnFemale";
            rbtnFemale.Size = new Size(107, 34);
            rbtnFemale.TabIndex = 12;
            rbtnFemale.TabStop = true;
            rbtnFemale.Text = "Wanita";
            rbtnFemale.UseVisualStyleBackColor = false;
            rbtnFemale.CheckedChanged += rbtnFemale_CheckedChanged;
            // 
            // txtHip
            // 
            txtHip.BackColor = Color.WhiteSmoke;
            txtHip.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtHip.ForeColor = SystemColors.Desktop;
            txtHip.Location = new Point(420, 305);
            txtHip.Name = "txtHip";
            txtHip.PlaceholderText = "Masukkan LG";
            txtHip.Size = new Size(220, 39);
            txtHip.TabIndex = 14;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(62, 70);
            label1.Name = "label1";
            label1.Size = new Size(178, 30);
            label1.TabIndex = 16;
            label1.Text = "Berat Badan (BB)";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(62, 170);
            label2.Name = "label2";
            label2.Size = new Size(188, 30);
            label2.TabIndex = 17;
            label2.Text = "Tinggi Badan (TB)";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(56, 270);
            label3.Name = "label3";
            label3.Size = new Size(54, 30);
            label3.TabIndex = 18;
            label3.Text = "Usia";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(422, 68);
            label4.Name = "label4";
            label4.Size = new Size(191, 30);
            label4.TabIndex = 19;
            label4.Text = "Lingkar Leher (LL)";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(426, 161);
            label5.Name = "label5";
            label5.Size = new Size(214, 30);
            label5.TabIndex = 20;
            label5.Text = "Lingkar Pinggul (LP)";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(425, 272);
            label7.Name = "label7";
            label7.Size = new Size(233, 30);
            label7.TabIndex = 22;
            label7.Text = "Lingkar Pinggang (LG)";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(278, 105);
            label8.Name = "label8";
            label8.Size = new Size(38, 30);
            label8.TabIndex = 23;
            label8.Text = "kg";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(278, 205);
            label9.Name = "label9";
            label9.Size = new Size(46, 30);
            label9.TabIndex = 24;
            label9.Text = "Cm";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(278, 305);
            label10.Name = "label10";
            label10.Size = new Size(73, 30);
            label10.TabIndex = 25;
            label10.Text = "Tahun";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(647, 202);
            label12.Name = "label12";
            label12.Size = new Size(46, 30);
            label12.TabIndex = 27;
            label12.Text = "Cm";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(644, 103);
            label13.Name = "label13";
            label13.Size = new Size(46, 30);
            label13.TabIndex = 26;
            label13.Text = "Cm";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.Location = new Point(646, 307);
            label14.Name = "label14";
            label14.Size = new Size(46, 30);
            label14.TabIndex = 29;
            label14.Text = "Cm";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.Location = new Point(54, 377);
            label15.Name = "label15";
            label15.Size = new Size(148, 30);
            label15.TabIndex = 30;
            label15.Text = "Jenis Kelamin";
            // 
            // lblHRZoneB
            // 
            lblHRZoneB.AutoSize = true;
            lblHRZoneB.BackColor = Color.Transparent;
            lblHRZoneB.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblHRZoneB.Location = new Point(328, 90);
            lblHRZoneB.Name = "lblHRZoneB";
            lblHRZoneB.Size = new Size(89, 32);
            lblHRZoneB.TabIndex = 31;
            lblHRZoneB.Text = "Zona 2";
            // 
            // lblHRZoneT
            // 
            lblHRZoneT.AutoSize = true;
            lblHRZoneT.BackColor = Color.Transparent;
            lblHRZoneT.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblHRZoneT.Location = new Point(328, 120);
            lblHRZoneT.Name = "lblHRZoneT";
            lblHRZoneT.Size = new Size(89, 32);
            lblHRZoneT.TabIndex = 32;
            lblHRZoneT.Text = "Zona 3";
            // 
            // lblBFPCat
            // 
            lblBFPCat.AutoSize = true;
            lblBFPCat.BackColor = Color.Transparent;
            lblBFPCat.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblBFPCat.Location = new Point(6, 147);
            lblBFPCat.Name = "lblBFPCat";
            lblBFPCat.Size = new Size(203, 38);
            lblBFPCat.TabIndex = 33;
            lblBFPCat.Text = "BFP Kategori :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(82, 75);
            label6.Name = "label6";
            label6.Size = new Size(0, 38);
            label6.TabIndex = 34;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.WhiteSmoke;
            groupBox1.Controls.Add(lblBFPW6);
            groupBox1.Controls.Add(lblBFPW1);
            groupBox1.Controls.Add(lblBFPW2);
            groupBox1.Controls.Add(lblBFPW3);
            groupBox1.Controls.Add(lblBFPW5);
            groupBox1.Controls.Add(lblBFPW4);
            groupBox1.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            groupBox1.Location = new Point(10, 330);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(351, 287);
            groupBox1.TabIndex = 45;
            groupBox1.TabStop = false;
            groupBox1.Text = "Wanita (%)";
            // 
            // lblBFPW6
            // 
            lblBFPW6.AutoSize = true;
            lblBFPW6.BackColor = Color.WhiteSmoke;
            lblBFPW6.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPW6.ForeColor = Color.Black;
            lblBFPW6.Location = new Point(0, 244);
            lblBFPW6.Name = "lblBFPW6";
            lblBFPW6.Size = new Size(346, 32);
            lblBFPW6.TabIndex = 51;
            lblBFPW6.Text = "   Obesitas                    ≥ 32    ";
            // 
            // lblBFPW1
            // 
            lblBFPW1.AutoSize = true;
            lblBFPW1.BackColor = Color.WhiteSmoke;
            lblBFPW1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPW1.ForeColor = Color.Black;
            lblBFPW1.Location = new Point(1, 44);
            lblBFPW1.Name = "lblBFPW1";
            lblBFPW1.Size = new Size(345, 32);
            lblBFPW1.TabIndex = 50;
            lblBFPW1.Text = "   Kurang Lemak           < 10    ";
            // 
            // lblBFPW2
            // 
            lblBFPW2.AutoSize = true;
            lblBFPW2.BackColor = Color.WhiteSmoke;
            lblBFPW2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPW2.ForeColor = Color.Black;
            lblBFPW2.Location = new Point(1, 84);
            lblBFPW2.Name = "lblBFPW2";
            lblBFPW2.Size = new Size(345, 32);
            lblBFPW2.TabIndex = 46;
            lblBFPW2.Text = "   Lemak Esensial       10 - 13    ";
            // 
            // lblBFPW3
            // 
            lblBFPW3.AutoSize = true;
            lblBFPW3.BackColor = Color.WhiteSmoke;
            lblBFPW3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPW3.ForeColor = Color.Black;
            lblBFPW3.Location = new Point(1, 124);
            lblBFPW3.Name = "lblBFPW3";
            lblBFPW3.Size = new Size(344, 32);
            lblBFPW3.TabIndex = 47;
            lblBFPW3.Text = "   Atlet                      14 - 20    ";
            // 
            // lblBFPW5
            // 
            lblBFPW5.AutoSize = true;
            lblBFPW5.BackColor = Color.WhiteSmoke;
            lblBFPW5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPW5.ForeColor = Color.Black;
            lblBFPW5.Location = new Point(1, 204);
            lblBFPW5.Name = "lblBFPW5";
            lblBFPW5.Size = new Size(345, 32);
            lblBFPW5.TabIndex = 49;
            lblBFPW5.Text = "   Rata-rata               25 - 31    ";
            // 
            // lblBFPW4
            // 
            lblBFPW4.AutoSize = true;
            lblBFPW4.BackColor = Color.WhiteSmoke;
            lblBFPW4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPW4.ForeColor = Color.Black;
            lblBFPW4.Location = new Point(1, 164);
            lblBFPW4.Name = "lblBFPW4";
            lblBFPW4.Size = new Size(347, 32);
            lblBFPW4.TabIndex = 48;
            lblBFPW4.Text = "   Kebugaran             21 - 24    ";
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.WhiteSmoke;
            groupBox2.Controls.Add(lblBFPP6);
            groupBox2.Controls.Add(lblBFPP1);
            groupBox2.Controls.Add(lblBFPP2);
            groupBox2.Controls.Add(lblBFPP3);
            groupBox2.Controls.Add(lblBFPP5);
            groupBox2.Controls.Add(lblBFPP4);
            groupBox2.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            groupBox2.Location = new Point(10, 37);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(351, 287);
            groupBox2.TabIndex = 46;
            groupBox2.TabStop = false;
            groupBox2.Text = "Pria (%)";
            // 
            // lblBFPP6
            // 
            lblBFPP6.AutoSize = true;
            lblBFPP6.BackColor = Color.WhiteSmoke;
            lblBFPP6.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPP6.ForeColor = Color.Black;
            lblBFPP6.Location = new Point(0, 243);
            lblBFPP6.Name = "lblBFPP6";
            lblBFPP6.Size = new Size(346, 32);
            lblBFPP6.TabIndex = 45;
            lblBFPP6.Text = "   Obesitas                    ≥ 25    ";
            // 
            // lblBFPP1
            // 
            lblBFPP1.AutoSize = true;
            lblBFPP1.BackColor = Color.WhiteSmoke;
            lblBFPP1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPP1.ForeColor = Color.Black;
            lblBFPP1.Location = new Point(1, 43);
            lblBFPP1.Name = "lblBFPP1";
            lblBFPP1.Size = new Size(349, 32);
            lblBFPP1.TabIndex = 44;
            lblBFPP1.Text = "   Kurang Lemak           < 2      ";
            // 
            // lblBFPP2
            // 
            lblBFPP2.AutoSize = true;
            lblBFPP2.BackColor = Color.WhiteSmoke;
            lblBFPP2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPP2.ForeColor = Color.Black;
            lblBFPP2.Location = new Point(1, 83);
            lblBFPP2.Name = "lblBFPP2";
            lblBFPP2.Size = new Size(346, 32);
            lblBFPP2.TabIndex = 40;
            lblBFPP2.Text = "   Lemak Esensial        2 - 5      ";
            // 
            // lblBFPP3
            // 
            lblBFPP3.AutoSize = true;
            lblBFPP3.BackColor = Color.WhiteSmoke;
            lblBFPP3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPP3.ForeColor = Color.Black;
            lblBFPP3.Location = new Point(1, 123);
            lblBFPP3.Name = "lblBFPP3";
            lblBFPP3.Size = new Size(344, 32);
            lblBFPP3.TabIndex = 41;
            lblBFPP3.Text = "   Atlet                        6 - 13    ";
            // 
            // lblBFPP5
            // 
            lblBFPP5.AutoSize = true;
            lblBFPP5.BackColor = Color.WhiteSmoke;
            lblBFPP5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPP5.ForeColor = Color.Black;
            lblBFPP5.Location = new Point(1, 203);
            lblBFPP5.Name = "lblBFPP5";
            lblBFPP5.Size = new Size(346, 32);
            lblBFPP5.TabIndex = 43;
            lblBFPP5.Text = "   Rata-rata               18 - 24    ";
            // 
            // lblBFPP4
            // 
            lblBFPP4.AutoSize = true;
            lblBFPP4.BackColor = Color.WhiteSmoke;
            lblBFPP4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBFPP4.ForeColor = Color.Black;
            lblBFPP4.Location = new Point(1, 163);
            lblBFPP4.Name = "lblBFPP4";
            lblBFPP4.Size = new Size(344, 32);
            lblBFPP4.TabIndex = 42;
            lblBFPP4.Text = "   Kebugaran             14 - 17    ";
            // 
            // groupBox3
            // 
            groupBox3.BackColor = Color.WhiteSmoke;
            groupBox3.Controls.Add(lblBMICat1);
            groupBox3.Controls.Add(lblBMICat2);
            groupBox3.Controls.Add(lblBMICat4);
            groupBox3.Controls.Add(lblBMICat3);
            groupBox3.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            groupBox3.Location = new Point(12, 37);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(459, 247);
            groupBox3.TabIndex = 46;
            groupBox3.TabStop = false;
            groupBox3.Text = "Kategori BMI (kg/m²)";
            // 
            // lblBMICat1
            // 
            lblBMICat1.AutoSize = true;
            lblBMICat1.BackColor = Color.WhiteSmoke;
            lblBMICat1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBMICat1.ForeColor = Color.Black;
            lblBMICat1.Location = new Point(2, 54);
            lblBMICat1.Name = "lblBMICat1";
            lblBMICat1.Size = new Size(455, 32);
            lblBMICat1.TabIndex = 35;
            lblBMICat1.Text = "   Berat Badan Kurang             < 18,5      ";
            // 
            // lblBMICat2
            // 
            lblBMICat2.AutoSize = true;
            lblBMICat2.BackColor = Color.WhiteSmoke;
            lblBMICat2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBMICat2.ForeColor = Color.Black;
            lblBMICat2.Location = new Point(2, 101);
            lblBMICat2.Name = "lblBMICat2";
            lblBMICat2.Size = new Size(454, 32);
            lblBMICat2.TabIndex = 37;
            lblBMICat2.Text = "   Normal                           18,5 – 24,9     ";
            // 
            // lblBMICat4
            // 
            lblBMICat4.AutoSize = true;
            lblBMICat4.BackColor = Color.WhiteSmoke;
            lblBMICat4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBMICat4.ForeColor = Color.Black;
            lblBMICat4.Location = new Point(0, 193);
            lblBMICat4.Name = "lblBMICat4";
            lblBMICat4.Size = new Size(458, 32);
            lblBMICat4.TabIndex = 39;
            lblBMICat4.Text = "   Obesitas                               ≥ 30         ";
            // 
            // lblBMICat3
            // 
            lblBMICat3.AutoSize = true;
            lblBMICat3.BackColor = Color.WhiteSmoke;
            lblBMICat3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBMICat3.ForeColor = Color.Black;
            lblBMICat3.Location = new Point(2, 148);
            lblBMICat3.Name = "lblBMICat3";
            lblBMICat3.Size = new Size(455, 32);
            lblBMICat3.TabIndex = 38;
            lblBMICat3.Text = "   Berat Badan Berlebih       25 – 29,9      ";
            // 
            // groupBox4
            // 
            groupBox4.BackColor = Color.WhiteSmoke;
            groupBox4.Controls.Add(lblBMRCalHr);
            groupBox4.Controls.Add(lblBMRCalHs);
            groupBox4.Controls.Add(label45);
            groupBox4.Controls.Add(label46);
            groupBox4.Controls.Add(lblBMRCalMid);
            groupBox4.Controls.Add(label48);
            groupBox4.Controls.Add(lblBMRCalLr);
            groupBox4.Controls.Add(label50);
            groupBox4.Controls.Add(lblBMRCalLs);
            groupBox4.Controls.Add(label52);
            groupBox4.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            groupBox4.Location = new Point(6, 293);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(391, 253);
            groupBox4.TabIndex = 47;
            groupBox4.TabStop = false;
            groupBox4.Text = "Kalori Harian (Calories)";
            // 
            // lblBMRCalHr
            // 
            lblBMRCalHr.AutoSize = true;
            lblBMRCalHr.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBMRCalHr.Location = new Point(227, 165);
            lblBMRCalHr.Name = "lblBMRCalHr";
            lblBMRCalHr.Size = new Size(147, 32);
            lblBMRCalHr.TabIndex = 43;
            lblBMRCalHr.Text = "1.725 x BMR";
            // 
            // lblBMRCalHs
            // 
            lblBMRCalHs.AutoSize = true;
            lblBMRCalHs.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBMRCalHs.Location = new Point(227, 203);
            lblBMRCalHs.Name = "lblBMRCalHs";
            lblBMRCalHs.Size = new Size(121, 32);
            lblBMRCalHs.TabIndex = 44;
            lblBMRCalHs.Text = "1.9 x BMR";
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label45.Location = new Point(28, 51);
            label45.Name = "label45";
            label45.Size = new Size(118, 32);
            label45.TabIndex = 35;
            label45.Text = "Sedentari";
            // 
            // label46
            // 
            label46.AutoSize = true;
            label46.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label46.ForeColor = SystemColors.ActiveCaptionText;
            label46.Location = new Point(28, 88);
            label46.Name = "label46";
            label46.Size = new Size(149, 32);
            label46.TabIndex = 36;
            label46.Text = "Aktif Ringan";
            // 
            // lblBMRCalMid
            // 
            lblBMRCalMid.AutoSize = true;
            lblBMRCalMid.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBMRCalMid.Location = new Point(227, 129);
            lblBMRCalMid.Name = "lblBMRCalMid";
            lblBMRCalMid.Size = new Size(134, 32);
            lblBMRCalMid.TabIndex = 42;
            lblBMRCalMid.Text = "1.55 x BMR";
            // 
            // label48
            // 
            label48.AutoSize = true;
            label48.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label48.Location = new Point(28, 126);
            label48.Name = "label48";
            label48.Size = new Size(154, 32);
            label48.TabIndex = 37;
            label48.Text = "Aktif Sedang";
            // 
            // lblBMRCalLr
            // 
            lblBMRCalLr.AutoSize = true;
            lblBMRCalLr.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBMRCalLr.Location = new Point(227, 90);
            lblBMRCalLr.Name = "lblBMRCalLr";
            lblBMRCalLr.Size = new Size(147, 32);
            lblBMRCalLr.TabIndex = 41;
            lblBMRCalLr.Text = "1.375 x BMR";
            // 
            // label50
            // 
            label50.AutoSize = true;
            label50.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label50.Location = new Point(28, 161);
            label50.Name = "label50";
            label50.Size = new Size(132, 32);
            label50.TabIndex = 38;
            label50.Text = "Aktif Berat";
            // 
            // lblBMRCalLs
            // 
            lblBMRCalLs.AutoSize = true;
            lblBMRCalLs.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblBMRCalLs.Location = new Point(227, 51);
            lblBMRCalLs.Name = "lblBMRCalLs";
            lblBMRCalLs.Size = new Size(121, 32);
            lblBMRCalLs.TabIndex = 40;
            lblBMRCalLs.Text = "1.2 x BMR";
            // 
            // label52
            // 
            label52.AutoSize = true;
            label52.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label52.Location = new Point(28, 197);
            label52.Name = "label52";
            label52.Size = new Size(149, 32);
            label52.TabIndex = 39;
            label52.Text = "Sangat Aktif";
            // 
            // lblBMICat
            // 
            lblBMICat.AutoSize = true;
            lblBMICat.BackColor = Color.Transparent;
            lblBMICat.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblBMICat.Location = new Point(6, 144);
            lblBMICat.Name = "lblBMICat";
            lblBMICat.Size = new Size(207, 38);
            lblBMICat.TabIndex = 48;
            lblBMICat.Text = "BMI Kategori :";
            // 
            // lblHRZoneA
            // 
            lblHRZoneA.AutoSize = true;
            lblHRZoneA.BackColor = Color.Transparent;
            lblHRZoneA.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblHRZoneA.Location = new Point(328, 153);
            lblHRZoneA.Name = "lblHRZoneA";
            lblHRZoneA.Size = new Size(90, 32);
            lblHRZoneA.TabIndex = 50;
            lblHRZoneA.Text = "Zona 4";
            // 
            // lblHRZoneAB
            // 
            lblHRZoneAB.AutoSize = true;
            lblHRZoneAB.BackColor = Color.Transparent;
            lblHRZoneAB.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblHRZoneAB.Location = new Point(328, 185);
            lblHRZoneAB.Name = "lblHRZoneAB";
            lblHRZoneAB.Size = new Size(89, 32);
            lblHRZoneAB.TabIndex = 51;
            lblHRZoneAB.Text = "Zona 5";
            // 
            // groupBox5
            // 
            groupBox5.BackColor = Color.WhiteSmoke;
            groupBox5.Controls.Add(label38);
            groupBox5.Controls.Add(label41);
            groupBox5.Controls.Add(label47);
            groupBox5.Controls.Add(label49);
            groupBox5.Controls.Add(label51);
            groupBox5.Controls.Add(lblHRZoneT);
            groupBox5.Controls.Add(lblHRZoneAB);
            groupBox5.Controls.Add(lblHRZoneBB);
            groupBox5.Controls.Add(lblHRZoneA);
            groupBox5.Controls.Add(lblHRZoneB);
            groupBox5.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            groupBox5.Location = new Point(8, 296);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(479, 253);
            groupBox5.TabIndex = 47;
            groupBox5.TabStop = false;
            groupBox5.Text = "Heart Rate Zone (BPM)";
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.BackColor = Color.Transparent;
            label38.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label38.Location = new Point(26, 120);
            label38.Name = "label38";
            label38.Size = new Size(99, 32);
            label38.TabIndex = 54;
            label38.Text = "Aerobik";
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.BackColor = Color.Transparent;
            label41.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label41.Location = new Point(26, 185);
            label41.Name = "label41";
            label41.Size = new Size(118, 32);
            label41.TabIndex = 56;
            label41.Text = "Maksimal";
            // 
            // label47
            // 
            label47.AutoSize = true;
            label47.BackColor = Color.Transparent;
            label47.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label47.Location = new Point(26, 60);
            label47.Name = "label47";
            label47.Size = new Size(128, 32);
            label47.TabIndex = 52;
            label47.Text = "Pemulihan";
            // 
            // label49
            // 
            label49.AutoSize = true;
            label49.BackColor = Color.Transparent;
            label49.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label49.Location = new Point(26, 152);
            label49.Name = "label49";
            label49.Size = new Size(126, 32);
            label49.TabIndex = 55;
            label49.Text = "Anaerobik";
            // 
            // label51
            // 
            label51.AutoSize = true;
            label51.BackColor = Color.Transparent;
            label51.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label51.Location = new Point(26, 90);
            label51.Name = "label51";
            label51.Size = new Size(229, 32);
            label51.TabIndex = 53;
            label51.Text = "Pembakaran Lemak";
            // 
            // groupBox6
            // 
            groupBox6.BackColor = Color.Transparent;
            groupBox6.Controls.Add(label53);
            groupBox6.Controls.Add(btnClear);
            groupBox6.Controls.Add(txtHip);
            groupBox6.Controls.Add(txtWeight);
            groupBox6.Controls.Add(txtHeight);
            groupBox6.Controls.Add(txtAge);
            groupBox6.Controls.Add(txtNeck);
            groupBox6.Controls.Add(txtWaist);
            groupBox6.Controls.Add(rbtnMale);
            groupBox6.Controls.Add(rbtnFemale);
            groupBox6.Controls.Add(label1);
            groupBox6.Controls.Add(btnCalculate);
            groupBox6.Controls.Add(label15);
            groupBox6.Controls.Add(btnClearH);
            groupBox6.Controls.Add(label2);
            groupBox6.Controls.Add(label14);
            groupBox6.Controls.Add(label3);
            groupBox6.Controls.Add(label12);
            groupBox6.Controls.Add(label4);
            groupBox6.Controls.Add(label13);
            groupBox6.Controls.Add(label5);
            groupBox6.Controls.Add(label10);
            groupBox6.Controls.Add(label7);
            groupBox6.Controls.Add(label9);
            groupBox6.Controls.Add(label8);
            groupBox6.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox6.Location = new Point(17, 25);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(731, 622);
            groupBox6.TabIndex = 49;
            groupBox6.TabStop = false;
            groupBox6.Text = "Input Parameter";
            // 
            // label53
            // 
            label53.AutoSize = true;
            label53.BackColor = Color.Transparent;
            label53.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label53.ForeColor = Color.Firebrick;
            label53.Location = new Point(420, 347);
            label53.Name = "label53";
            label53.Size = new Size(157, 28);
            label53.TabIndex = 32;
            label53.Text = "* khusus wanita";
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.Transparent;
            btnClear.BackgroundImageLayout = ImageLayout.None;
            btnClear.FlatAppearance.BorderSize = 0;
            btnClear.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnClear.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnClear.FlatStyle = FlatStyle.Flat;
            btnClear.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnClear.ForeColor = SystemColors.ActiveCaptionText;
            btnClear.Image = (Image)resources.GetObject("btnClear.Image");
            btnClear.Location = new Point(397, 519);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(293, 81);
            btnClear.TabIndex = 31;
            btnClear.Text = "Bersihkan Input";
            btnClear.UseVisualStyleBackColor = false;
            btnClear.Click += btnClear_Click;
            // 
            // btnClearH
            // 
            btnClearH.BackColor = Color.Transparent;
            btnClearH.BackgroundImageLayout = ImageLayout.None;
            btnClearH.FlatAppearance.BorderSize = 0;
            btnClearH.FlatAppearance.MouseDownBackColor = Color.Transparent;
            btnClearH.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnClearH.FlatStyle = FlatStyle.Flat;
            btnClearH.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnClearH.ForeColor = SystemColors.ActiveCaptionText;
            btnClearH.Image = (Image)resources.GetObject("btnClearH.Image");
            btnClearH.Location = new Point(56, 518);
            btnClearH.Name = "btnClearH";
            btnClearH.Size = new Size(298, 83);
            btnClearH.TabIndex = 32;
            btnClearH.Text = "Bersihkan Hasil";
            btnClearH.UseVisualStyleBackColor = false;
            btnClearH.Click += btnClearH_Click;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.WhiteSmoke;
            textBox1.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            textBox1.Location = new Point(20, 358);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(695, 134);
            textBox1.TabIndex = 50;
            textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.WhiteSmoke;
            textBox2.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            textBox2.Location = new Point(20, 108);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(695, 83);
            textBox2.TabIndex = 51;
            textBox2.Text = "Klasifikasi status berat badan berdasarkan BMI dalam satuan kg/m². Angka ini dihitung dari berat badan (kg) dibagi tinggi badan kuadrat (m²).";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.WhiteSmoke;
            textBox3.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            textBox3.Location = new Point(20, 233);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.ReadOnly = true;
            textBox3.Size = new Size(695, 87);
            textBox3.TabIndex = 52;
            textBox3.Text = "Kalori harian berdasarkan aktivitas fisik. BMR adalah jumlah kalori yang dibutuhkan tubuh untuk mempertahankan fungsi vital saat istirahat.";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.WhiteSmoke;
            textBox4.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            textBox4.Location = new Point(20, 530);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.ReadOnly = true;
            textBox4.Size = new Size(695, 115);
            textBox4.TabIndex = 53;
            textBox4.Text = "Zona detak jantung berdasarkan persentase HR Max, yang digunakan untuk tujuan kebugaran tertentu seperti pemulihan, pembakaran lemak, aerobik, anaerobik, dan maksimal.\r\n";
            // 
            // label54
            // 
            label54.AutoSize = true;
            label54.BackColor = Color.Transparent;
            label54.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label54.Location = new Point(20, 73);
            label54.Name = "label54";
            label54.Size = new Size(293, 32);
            label54.TabIndex = 54;
            label54.Text = "BMI (Body Mass Index): ";
            // 
            // label55
            // 
            label55.AutoSize = true;
            label55.BackColor = Color.Transparent;
            label55.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label55.Location = new Point(20, 189);
            label55.Name = "label55";
            label55.Size = new Size(345, 32);
            label55.TabIndex = 55;
            label55.Text = "BMR (Basal Metabolic Rate): ";
            // 
            // label56
            // 
            label56.AutoSize = true;
            label56.BackColor = Color.Transparent;
            label56.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label56.Location = new Point(20, 323);
            label56.Name = "label56";
            label56.Size = new Size(320, 32);
            label56.TabIndex = 56;
            label56.Text = "BFP (Body Fat Percentage):";
            // 
            // label57
            // 
            label57.AutoSize = true;
            label57.BackColor = Color.Transparent;
            label57.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label57.Location = new Point(20, 495);
            label57.Name = "label57";
            label57.Size = new Size(387, 32);
            label57.TabIndex = 57;
            label57.Text = "HR Max (Maximum Heart Rate): ";
            // 
            // txtBoxBFP
            // 
            txtBoxBFP.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            txtBoxBFP.Location = new Point(6, 298);
            txtBoxBFP.Multiline = true;
            txtBoxBFP.Name = "txtBoxBFP";
            txtBoxBFP.PlaceholderText = "Silahkan Input Parameter dan Kalkulasi";
            txtBoxBFP.ReadOnly = true;
            txtBoxBFP.ScrollBars = ScrollBars.Vertical;
            txtBoxBFP.Size = new Size(368, 248);
            txtBoxBFP.TabIndex = 58;
            // 
            // txtBoxBMI
            // 
            txtBoxBMI.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            txtBoxBMI.Location = new Point(6, 296);
            txtBoxBMI.Multiline = true;
            txtBoxBMI.Name = "txtBoxBMI";
            txtBoxBMI.PlaceholderText = "Silahkan Input Parameter dan Kalkulasi";
            txtBoxBMI.ReadOnly = true;
            txtBoxBMI.ScrollBars = ScrollBars.Vertical;
            txtBoxBMI.Size = new Size(459, 249);
            txtBoxBMI.TabIndex = 59;
            // 
            // groupBox7
            // 
            groupBox7.BackColor = Color.Transparent;
            groupBox7.Controls.Add(pictureBox1);
            groupBox7.Controls.Add(groupBox3);
            groupBox7.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox7.Location = new Point(748, 704);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new Size(484, 622);
            groupBox7.TabIndex = 62;
            groupBox7.TabStop = false;
            groupBox7.Text = "Body Mass Index";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImageLayout = ImageLayout.None;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(119, 366);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(209, 209);
            pictureBox1.TabIndex = 62;
            pictureBox1.TabStop = false;
            // 
            // label59
            // 
            label59.AutoSize = true;
            label59.BackColor = Color.Transparent;
            label59.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            label59.Location = new Point(6, 250);
            label59.Name = "label59";
            label59.Size = new Size(238, 38);
            label59.TabIndex = 60;
            label59.Text = "Keterangan BMI:";
            // 
            // groupBox8
            // 
            groupBox8.BackColor = Color.Transparent;
            groupBox8.Controls.Add(textBox4);
            groupBox8.Controls.Add(textBox1);
            groupBox8.Controls.Add(textBox2);
            groupBox8.Controls.Add(textBox3);
            groupBox8.Controls.Add(label54);
            groupBox8.Controls.Add(label55);
            groupBox8.Controls.Add(label56);
            groupBox8.Controls.Add(label57);
            groupBox8.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox8.Location = new Point(11, 655);
            groupBox8.Name = "groupBox8";
            groupBox8.Size = new Size(731, 671);
            groupBox8.TabIndex = 63;
            groupBox8.TabStop = false;
            groupBox8.Text = "Calculator Information";
            // 
            // label58
            // 
            label58.AutoSize = true;
            label58.BackColor = Color.Transparent;
            label58.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            label58.Location = new Point(6, 249);
            label58.Name = "label58";
            label58.Size = new Size(234, 38);
            label58.TabIndex = 59;
            label58.Text = "Keterangan BFP:";
            // 
            // label65
            // 
            label65.AutoSize = true;
            label65.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            label65.Location = new Point(15, 86);
            label65.Name = "label65";
            label65.Size = new Size(846, 28);
            label65.TabIndex = 67;
            label65.Text = "Sedentari:   Aktivitas harian sangat rendah, pekerjaan duduk sepanjang hari tanpa olahraga.";
            // 
            // label60
            // 
            label60.AutoSize = true;
            label60.BackColor = Color.Transparent;
            label60.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            label60.Location = new Point(8, 41);
            label60.Name = "label60";
            label60.Size = new Size(348, 38);
            label60.TabIndex = 61;
            label60.Text = "Keterangan Kalori Harian";
            // 
            // groupBox10
            // 
            groupBox10.BackColor = Color.Transparent;
            groupBox10.Controls.Add(label66);
            groupBox10.Controls.Add(label67);
            groupBox10.Controls.Add(label64);
            groupBox10.Controls.Add(label63);
            groupBox10.Controls.Add(label62);
            groupBox10.Controls.Add(label61);
            groupBox10.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox10.Location = new Point(1622, 701);
            groupBox10.Name = "groupBox10";
            groupBox10.Size = new Size(921, 306);
            groupBox10.TabIndex = 65;
            groupBox10.TabStop = false;
            groupBox10.Text = "Heart Rate Zone";
            // 
            // label66
            // 
            label66.AutoSize = true;
            label66.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            label66.Location = new Point(15, 244);
            label66.Name = "label66";
            label66.Size = new Size(499, 30);
            label66.TabIndex = 66;
            label66.Text = "Zona 5:    Performa maksimal untuk atlet terlatih.";
            // 
            // label67
            // 
            label67.AutoSize = true;
            label67.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            label67.Location = new Point(15, 206);
            label67.Name = "label67";
            label67.Size = new Size(647, 30);
            label67.TabIndex = 65;
            label67.Text = "Zona 4:    Meningkatkan power, speed, dan kapasitas anaerobik.";
            // 
            // label64
            // 
            label64.AutoSize = true;
            label64.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            label64.Location = new Point(15, 172);
            label64.Name = "label64";
            label64.Size = new Size(493, 30);
            label64.TabIndex = 64;
            label64.Text = "Zona 3:    Melatih daya tahan dan kardiovaskular";
            // 
            // label63
            // 
            label63.AutoSize = true;
            label63.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            label63.Location = new Point(15, 134);
            label63.Name = "label63";
            label63.Size = new Size(506, 30);
            label63.TabIndex = 63;
            label63.Text = "Zona 2:    Membakar lemak sebagai energi utama.";
            // 
            // label62
            // 
            label62.AutoSize = true;
            label62.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            label62.Location = new Point(15, 96);
            label62.Name = "label62";
            label62.Size = new Size(638, 30);
            label62.TabIndex = 45;
            label62.Text = "Zona 1:    Latihan ringan untuk pemulihan dan kesehatan dasar.";
            // 
            // label61
            // 
            label61.AutoSize = true;
            label61.BackColor = Color.Transparent;
            label61.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            label61.Location = new Point(8, 54);
            label61.Name = "label61";
            label61.Size = new Size(297, 38);
            label61.TabIndex = 62;
            label61.Text = "Keterangan HR Zone:";
            // 
            // lblHRMax
            // 
            lblHRMax.AutoSize = true;
            lblHRMax.BackColor = Color.Transparent;
            lblHRMax.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblHRMax.Location = new Point(8, 147);
            lblHRMax.Name = "lblHRMax";
            lblHRMax.Size = new Size(231, 38);
            lblHRMax.TabIndex = 61;
            lblHRMax.Text = "Heart Rate Max:";
            // 
            // groupBox11
            // 
            groupBox11.BackColor = Color.Transparent;
            groupBox11.Controls.Add(groupBox2);
            groupBox11.Controls.Add(groupBox1);
            groupBox11.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox11.Location = new Point(1238, 704);
            groupBox11.Name = "groupBox11";
            groupBox11.Size = new Size(378, 625);
            groupBox11.TabIndex = 67;
            groupBox11.TabStop = false;
            groupBox11.Text = "Body Fat Percentage";
            // 
            // label68
            // 
            label68.AutoSize = true;
            label68.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            label68.Location = new Point(15, 127);
            label68.Name = "label68";
            label68.Size = new Size(809, 28);
            label68.TabIndex = 68;
            label68.Text = "Aktif Ringan:   Aktivitas fisik ringan, jalan santai atau yang memerlukan sedikit gerakan.";
            // 
            // label69
            // 
            label69.AutoSize = true;
            label69.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            label69.Location = new Point(15, 169);
            label69.Name = "label69";
            label69.Size = new Size(867, 28);
            label69.TabIndex = 69;
            label69.Text = "Aktif Sedang:   Kombinasi pekerjaan aktif dan olahraga teratur, jogging atau gym per minggu.";
            // 
            // label70
            // 
            label70.AutoSize = true;
            label70.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            label70.Location = new Point(15, 209);
            label70.Name = "label70";
            label70.Size = new Size(808, 28);
            label70.TabIndex = 70;
            label70.Text = "Aktif Berat:   Aktivitas fisik berat, pekerjaan fisik intensif atau olahraga berat setiap hari.";
            // 
            // label71
            // 
            label71.AutoSize = true;
            label71.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            label71.Location = new Point(15, 249);
            label71.Name = "label71";
            label71.Size = new Size(862, 28);
            label71.TabIndex = 71;
            label71.Text = "Sangat Aktif:   Aktivitas fisik sangat intensif, biasanya oleh atlet profesional atau pekerja fisik.\r\n";
            // 
            // groupBox12
            // 
            groupBox12.BackColor = Color.Transparent;
            groupBox12.Controls.Add(label71);
            groupBox12.Controls.Add(label60);
            groupBox12.Controls.Add(label6);
            groupBox12.Controls.Add(label70);
            groupBox12.Controls.Add(label65);
            groupBox12.Controls.Add(label68);
            groupBox12.Controls.Add(label69);
            groupBox12.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox12.Location = new Point(1622, 1013);
            groupBox12.Name = "groupBox12";
            groupBox12.Size = new Size(921, 316);
            groupBox12.TabIndex = 67;
            groupBox12.TabStop = false;
            groupBox12.Text = "Basal Metabolic Rate";
            // 
            // groupBox9
            // 
            groupBox9.BackColor = Color.Transparent;
            groupBox9.Controls.Add(lblBMI);
            groupBox9.Controls.Add(lblBMICat);
            groupBox9.Controls.Add(txtBoxBMI);
            groupBox9.Controls.Add(label59);
            groupBox9.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox9.Location = new Point(754, 95);
            groupBox9.Name = "groupBox9";
            groupBox9.Size = new Size(478, 554);
            groupBox9.TabIndex = 64;
            groupBox9.TabStop = false;
            groupBox9.Text = "BMI Output";
            // 
            // groupBox13
            // 
            groupBox13.BackColor = Color.Transparent;
            groupBox13.Controls.Add(lblBFP);
            groupBox13.Controls.Add(lblBFPCat);
            groupBox13.Controls.Add(label58);
            groupBox13.Controls.Add(txtBoxBFP);
            groupBox13.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox13.Location = new Point(1240, 95);
            groupBox13.Name = "groupBox13";
            groupBox13.Size = new Size(378, 554);
            groupBox13.TabIndex = 65;
            groupBox13.TabStop = false;
            groupBox13.Text = "BFP Output";
            // 
            // groupBox14
            // 
            groupBox14.BackColor = Color.Transparent;
            groupBox14.Controls.Add(lblHRMax);
            groupBox14.Controls.Add(groupBox5);
            groupBox14.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox14.Location = new Point(1629, 95);
            groupBox14.Name = "groupBox14";
            groupBox14.Size = new Size(496, 554);
            groupBox14.TabIndex = 68;
            groupBox14.TabStop = false;
            groupBox14.Text = "HR Zone Output";
            // 
            // groupBox15
            // 
            groupBox15.BackColor = Color.Transparent;
            groupBox15.Controls.Add(groupBox4);
            groupBox15.Controls.Add(lblBMR);
            groupBox15.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox15.Location = new Point(2137, 95);
            groupBox15.Name = "groupBox15";
            groupBox15.Size = new Size(406, 554);
            groupBox15.TabIndex = 69;
            groupBox15.TabStop = false;
            groupBox15.Text = "BMR Output";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.GhostWhite;
            BackgroundImage = Properties.Resources.latarrr;
            ClientSize = new Size(2564, 1410);
            Controls.Add(groupBox15);
            Controls.Add(groupBox14);
            Controls.Add(groupBox13);
            Controls.Add(groupBox9);
            Controls.Add(groupBox12);
            Controls.Add(groupBox11);
            Controls.Add(groupBox10);
            Controls.Add(groupBox8);
            Controls.Add(groupBox7);
            Controls.Add(groupBox6);
            Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ActiveCaptionText;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "Fitness Calculator";
            WindowState = FormWindowState.Maximized;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox8.ResumeLayout(false);
            groupBox8.PerformLayout();
            groupBox10.ResumeLayout(false);
            groupBox10.PerformLayout();
            groupBox11.ResumeLayout(false);
            groupBox12.ResumeLayout(false);
            groupBox12.PerformLayout();
            groupBox9.ResumeLayout(false);
            groupBox9.PerformLayout();
            groupBox13.ResumeLayout(false);
            groupBox13.PerformLayout();
            groupBox14.ResumeLayout(false);
            groupBox14.PerformLayout();
            groupBox15.ResumeLayout(false);
            groupBox15.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label lblBMI;
        private Label lblBMR;
        private Label lblHRZoneBB;
        private Label lblBFP;
        private TextBox txtWeight;
        private TextBox txtHeight;
        private TextBox txtAge;
        private TextBox txtNeck;
        private TextBox txtWaist;
        private Button btnCalculate;
        private RadioButton rbtnMale;
        private RadioButton rbtnFemale;
        private TextBox txtHip;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label lblHRZoneB;
        private Label lblHRZoneT;
        private Label lblBFPCat;
        private Label label6;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private Label lblBMICat2;
        private Label lblBMICat3;
        private Label lblBMICat4;
        private GroupBox groupBox4;
        private Label lblBMRCalHr;
        private Label lblBMRCalHs;
        private Label label45;
        private Label label46;
        private Label lblBMRCalMid;
        private Label label48;
        private Label lblBMRCalLr;
        private Label label50;
        private Label lblBMRCalLs;
        private Label label52;
        private Label lblBMICat;
        private Label lblHRZoneA;
        private Label lblHRZoneAB;
        private GroupBox groupBox5;
        private Label label38;
        private Label label41;
        private Label label47;
        private Label label49;
        private Label label51;
        private GroupBox groupBox6;
        private Button btnClear;
        private Button btnClearH;
        private TextBox textBox1;
        private Label label53;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Label label54;
        private Label label55;
        private Label label56;
        private Label label57;
        private TextBox txtBoxBFP;
        private TextBox txtBoxBMI;
        private GroupBox groupBox7;
        private GroupBox groupBox8;
        private GroupBox groupBox10;
        private Label label59;
        private Label label58;
        private Label label60;
        private Label label61;
        private PictureBox pictureBox1;
        private Label label62;
        private Label label64;
        private Label label63;
        private Label label66;
        private Label label67;
        private Label lblHRMax;
        private GroupBox groupBox11;
        private Label label65;
        private Label label71;
        private Label label70;
        private Label label69;
        private Label label68;
        private GroupBox groupBox12;
        private GroupBox groupBox9;
        private GroupBox groupBox13;
        private GroupBox groupBox14;
        private GroupBox groupBox15;
        private Label lblBMICat1;
        private Label lblBFPP1;
        private Label lblBFPP2;
        private Label lblBFPP3;
        private Label lblBFPP5;
        private Label lblBFPP4;
        private Label lblBFPP6;
        private Label lblBFPW6;
        private Label lblBFPW1;
        private Label lblBFPW2;
        private Label lblBFPW3;
        private Label lblBFPW5;
        private Label lblBFPW4;
    }
}
